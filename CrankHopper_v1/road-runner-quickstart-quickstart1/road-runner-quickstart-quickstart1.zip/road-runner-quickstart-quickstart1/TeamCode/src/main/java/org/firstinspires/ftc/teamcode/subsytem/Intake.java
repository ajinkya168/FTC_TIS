package org.firstinspires.ftc.teamcode.subsytem;

import static android.os.SystemClock.sleep;

import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.robotcore.external.navigation.CurrentUnit;


@Config
public class Intake {

    public DcMotorEx IntakeMotor=null;
    public Servo InR;
    public Servo InL;

    String intakeState="INIT";

    public static double leftServoGrippingPos = 0.53;//left servo 0.1594 for intake of  pixels

    public static double rightServoGrippingPos = (1.0 - leftServoGrippingPos);

    public static double leftServoInitPos = 0.2; //0.15 // left servo 0.829 for init
    public static double rightServoInitPos = (1.0 - leftServoInitPos);
    public static double LeftAutoStartIntakePose = 0.3;
    public static double RightAutoStartIntakePose = (1.0 - LeftAutoStartIntakePose);
    public static double CycleIntakrLeftServo = 0.1;
    public static double CycleIntakrRightServo = (1.0 - CycleIntakrLeftServo);;




    //distance of chassis from the wall = 149mm

    //left servo for second pixel = 0.609444444444
    //left servo for third pixel = 0.5794444
    //left servo for fourth pixel = 0.549444
    //left servo for first pixel = 0.63944444
    public static double pickFirstPixel = 0.3;//0.63944444;
    public static double pickSecondPixel = pickFirstPixel-0.03;//0.609444444
    public static double pickThirdPixel = pickSecondPixel-0.03;//0.579444444
    public static double pickFourthPixel = pickThirdPixel-0.03;//0.54944444



    //INTAKE MOTOR
    public static double intakeOnFor=1;
    public static double intakeREV=1;

    public Intake(HardwareMap hardwareMap, Telemetry telemetry) {
        InR = hardwareMap.get(Servo.class, "InR");
        InL = hardwareMap.get(Servo.class, "InL");
        IntakeMotor = hardwareMap.get(DcMotorEx.class, "In");

    }

    //TODO INTAKE SERVOS

    public void intakeInit(){
        intakeState="INIT";
        InR.setPosition(leftServoInitPos);
        InL.setPosition(rightServoInitPos);
    }
    public void intakeGrip(){
        intakeState="GRIP";
        InR.setPosition(leftServoGrippingPos);
        InL.setPosition(rightServoGrippingPos);
    }
    public void intakeAutoStart(){
        intakeState="GRIP";
        InR.setPosition(LeftAutoStartIntakePose);
        InL.setPosition(RightAutoStartIntakePose);
    }
    public void intakeCycle(){
        InR.setPosition(CycleIntakrRightServo);
        InL.setPosition(CycleIntakrLeftServo);
    }

    public void intakeStack(double PF){
        intakeState="GRIP";
        leftServoGrippingPos =PF;
        rightServoGrippingPos = (1.0 - leftServoGrippingPos);
        InR.setPosition(leftServoGrippingPos);
        InL.setPosition(rightServoGrippingPos);
    }
    public void ToUseWhenPixelGetsStuck(){
        if(IntakeMotor.getCurrent(CurrentUnit.AMPS)>1.5){
            intakeOnRev();
            sleep(500);
        }
    }


    public void intakeServoINC(){
        double leftpos=InL.getPosition()+0.01;
        double rigpos = 1 - leftpos;
        InL.setPosition(leftpos);
        InR.setPosition(rigpos);
    }
    public void intakeServoDEC(){
        double leftpos=InL.getPosition()-0.01;
        double rigpos = 1 - leftpos;
        InL.setPosition(leftpos);
        InR.setPosition(rigpos);
    }

    //TODO INTAKE MOTOR
    public void intakeMotor(double power){
        IntakeMotor.setPower(power);
    }

    public void intakeOnFor(){intakeMotor(-intakeOnFor);}
    public void intakeOnRev(){intakeMotor(intakeREV);}
    public void intakeOFF(){intakeMotor(0);}


    public void setIntakeServo(double lefpos) {
        double rigpos = 1 - lefpos;
        InL.setPosition(lefpos);
        InR.setPosition(rigpos);
    }







}
