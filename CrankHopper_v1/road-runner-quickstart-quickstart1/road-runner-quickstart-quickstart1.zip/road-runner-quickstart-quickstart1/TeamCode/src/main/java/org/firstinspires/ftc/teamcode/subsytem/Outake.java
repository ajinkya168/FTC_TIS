package org.firstinspires.ftc.teamcode.subsytem;

import static android.os.SystemClock.sleep;

import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

import org.checkerframework.checker.units.qual.C;
import org.firstinspires.ftc.robotcore.external.Telemetry;

@Config
public class Outake {


    public Servo outakeGrip,outakeArm;

    public static double gripperDropPixel1=0.5;
    public static double gripperDropPixel2=0.5;

    public static double gripperClose=0.5;
 

    public static double OuttakePixelGrip = 0.57; //0.6;//gripper close or initial position
    public static double OuttakePixelDrop = 0.4;
    public static double armGripPos=0.95;
    public static double armInitPos=0.95;
    public static double armPlacePos=0.22;






    public Outake(HardwareMap hardwareMap, Telemetry telemetry) {
        outakeGrip = hardwareMap.get(Servo.class, "out");
        outakeArm = hardwareMap.get(Servo.class, "outarm");
    }

    //TODO ARM POS

    public void outakeArmInit(){
       outakeArm.setPosition(armInitPos);
    }
    public void outakeArmPlace(){
        outakeArm.setPosition(armPlacePos);
    }
    public void outakeArmGripPos(){
        outakeArm.setPosition(armGripPos);
    }


    public void outakeArmINC(){
        outakeArm.setPosition(outakeArm.getPosition()+0.05);
    }

    public void outakeArmDEC(){
        outakeArm.setPosition(outakeArm.getPosition()-0.05);
    }


    ////TODO GRIPPER
    public void dropPixel1(){
//        outakeGrip.setPosition(OuttakePixelDrop)

        outakeGrip.setPosition(OuttakePixelDrop);
    }
    public void dropPixel2(){
        outakeGrip.setPosition(OuttakePixelGrip);
        sleep(1000);

        outakeGrip.setPosition(OuttakePixelDrop);
    }
    public void closeGripper(){
        outakeGrip.setPosition(OuttakePixelGrip);
    }
    public void openGripper(){
        outakeGrip.setPosition(OuttakePixelDrop);
    }


    public void outakeGripINC(){
        outakeGrip.setPosition(outakeGrip.getPosition()+0.05);
    }

    public void outakeGripDEC(){
        outakeGrip.setPosition(outakeGrip.getPosition()-0.05);
    }

}

